//Michael Weyman

#include <iostream>
#include <vector>
using namespace std;

class FancyVector {

	private: std::vector<int> fanVect;

	public:

	FancyVector(){}
			 
	FancyVector(int size)
		: fanVect(std::vector<int> (size)){}
	

	void pushBack(int a){
		fanVect.push_back(a);
	}

	int At(int index){
		return fanVect.at(index);
	}

	bool Empty(){
		return fanVect.empty();
	}

	int Size(){
		return fanVect.size();
	}

	int Size() const{
		return fanVect.size();
	}

	int operator [] (int a){
		return fanVect.at(a);
	}

	vector<int> AsVector() const{
		return fanVect ;
	}

	bool IsEmpty(){
		return fanVect.empty();
	}

	FancyVector operator << (int a){
		fanVect.push_back(a);
		return *this;
	}

	int operator () (int a){
		//if( a = -1)
			//a = 9;
		return fanVect.at(a);
	}

	FancyVector operator () (int a, int b){
		FancyVector temp;
		if( b > 10 )
			b = 10;
		for(int i = a; i < b; i++){
			temp.pushBack(fanVect.at(i));
		}
		return temp;
	}


};

ostream & operator << (ostream &out, FancyVector &fan){
	out << "[";
	for(int i = 0; i < fan.Size(); i++){
		cout << (i == 0 ? "":",") << fan.At(i);
	}
	out << "]" << endl;
	return out;
}