//Michael Weyman

#include "FancyVector.h";


int main( ) 
{ 
 FancyVector v ; 
 for( int i = 1 ; i <= 10 ; i++ ) 
 v << i ; 
 cout << v << endl ; 
 //cout << v( -1 ) << endl ; 
 cout << v( 2, 7 ) << endl ; 
// cout << v( -4, -2 ) << endl ; 
 //cout << v( -1, 3 ) << endl ; // same as v(0,3) 
 cout << v( 6, 15 ) << endl ; // same as v( 6, v.size() ) 
// cout << v( 6, -1 ) << endl ; // same output as above line 
// cout << v( 6, -100 ) << endl ; // invalid, should be blank 
 cout << v( 3, 1 ) << endl ; // invalid, should be blank 
// cout << v( -4, -5 ) << endl ; // invalid, should be blank 
 cout << v( 15, 18 ) << endl ; // invalid, should be blank 
 system( "PAUSE" ) ; 
 return 0 ; 
} 

