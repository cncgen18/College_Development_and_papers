This package contains various source code
files that are used in "Foundations of
Security: What Every Programmer Needs To
Know."  Depending upon what OS and
development environment you are using
compilation details will vary.

Please consult http://www.learnsecurity.com/ntk
for updates, and email any questions directly
to the author at daswani@learnsecurity.com.

